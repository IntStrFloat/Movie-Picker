// export const SERVER_URL = "http://192.168.62.166:8080";
export const SERVER_URL = "http://45.146.167.70:8080";
